<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/3/24
 * Time: 18:28
 */

namespace app\api\model;


class ProductProperty extends BaseModel
{

}