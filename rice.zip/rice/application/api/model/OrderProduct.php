<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/4/7
 * Time: 21:35
 */

namespace app\api\model;


class OrderProduct extends BaseModel
{

}