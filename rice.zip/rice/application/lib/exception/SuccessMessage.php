<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/3/25
 * Time: 19:25
 */

namespace app\lib\exception;


class SuccessMessage
{
    public $code = 201;
    public $msg = "调用接口成功";
    public $error_code = 0;
}