<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/3/25
 * Time: 21:22
 */

namespace app\lib\enum;


class ScopeEnum
{
    const User = 16;
    const Supper = 32;
}