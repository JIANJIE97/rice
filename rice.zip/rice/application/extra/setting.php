<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/3/31
 * Time: 15:40
 */

return [
    //图片前面部分url
    'img_prefix'=>'http://47.102.203.229/images',

    //token有效时间
    'token_expire_in' => 7200
];