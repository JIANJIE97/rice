<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/3/24
 * Time: 15:33
 */

return[
    'token_salt'=>'HHsTieBU377mJtKr',
    'pay_back_url' => 'http://2whczb.webx.cc/rice/public/index.php/api/v1/pay/notify'
    //替换'pay_back_url' => 'http://r.cn/api/v1/pay/notify'
];