<?php
//000000007200s:102:"{"session_key":"8JkocNm\/YBoDjuhFyEGQrw==","openid":"oKFP-4wyYvUqFis01gFytWLJhXr8","uid":2,"scope":16}";
?>