<?php
//000000007200s:102:"{"session_key":"e7x9ksBp7krjKLV+Tr\/hSg==","openid":"oKFP-4wyYvUqFis01gFytWLJhXr8","uid":2,"scope":16}";
?>