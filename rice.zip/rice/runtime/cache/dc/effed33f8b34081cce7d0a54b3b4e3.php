<?php
//000000007200s:101:"{"session_key":"fYl2AKtZhpM7Cyuh5Opqew==","openid":"oKFP-4wyYvUqFis01gFytWLJhXr8","uid":4,"scope":16}";
?>