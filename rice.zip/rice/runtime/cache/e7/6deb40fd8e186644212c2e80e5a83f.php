<?php
//000000007200s:102:"{"session_key":"owMcnaTWmSJxSaW8\/0L5EA==","openid":"oKFP-4wyYvUqFis01gFytWLJhXr8","uid":2,"scope":16}";
?>