<?php
//000000007200s:106:"{"session_key":"OEg3M+\/1V3T\/Os1\/44hrUg==","openid":"oKFP-46MU6KFiA_s-Cw7o0AThlaU","uid":"5","scope":16}";
?>