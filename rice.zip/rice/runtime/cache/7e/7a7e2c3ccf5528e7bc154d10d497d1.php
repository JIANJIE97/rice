<?php
//000000007200s:101:"{"session_key":"2CZJtP+3GfujMC9ilhuq+w==","openid":"oKFP-4wyYvUqFis01gFytWLJhXr8","uid":4,"scope":16}";
?>