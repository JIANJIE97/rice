<?php
//000000007200s:104:"{"session_key":"kw\/4OxskFej8QJZgdpKqFA==","openid":"oKFP-4wyYvUqFis01gFytWLJhXr8","uid":"4","scope":16}";
?>