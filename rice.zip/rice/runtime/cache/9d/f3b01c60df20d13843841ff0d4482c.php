<?php
//000000007000a:2:{s:12:"access_token";s:157:"21_5XpjPfRFNMnijwZnmjvpWaRSOwRjWnj4admKQfAT2ihzXGTiuvzGnOgbu3pni9D-LXt_Ru_NDvEoMJcETsHfvX2Bsn8SDCTMwKxZG7vJxP1mxgJx4QdVW7hD6CV17uofe8BY9utXy3o0OYATRGUdAEAHWK";s:10:"expires_in";i:7200;}
?>