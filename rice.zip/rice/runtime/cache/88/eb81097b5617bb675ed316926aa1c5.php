<?php
//000000007200s:101:"{"session_key":"IfflnPGM0tO2HB8+fIQf0g==","openid":"oKFP-4wyYvUqFis01gFytWLJhXr8","uid":4,"scope":16}";
?>