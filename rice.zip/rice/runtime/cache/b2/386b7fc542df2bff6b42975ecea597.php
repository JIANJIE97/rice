<?php
//000000007200s:104:"{"session_key":"AJKEE2rWL7tS4TmYcG1t\/w==","openid":"oKFP-46MU6KFiA_s-Cw7o0AThlaU","uid":"5","scope":16}";
?>