<?php
//000000007200s:101:"{"session_key":"kZ27v0IRnsE4k2wpypbxVQ==","openid":"oKFP-4wyYvUqFis01gFytWLJhXr8","uid":2,"scope":16}";
?>