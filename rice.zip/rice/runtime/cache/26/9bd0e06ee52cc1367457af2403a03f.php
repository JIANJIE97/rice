<?php
//000000007200s:102:"{"session_key":"0GDNwUTjC41wgveHwbN\/+A==","openid":"oKFP-4wyYvUqFis01gFytWLJhXr8","uid":4,"scope":16}";
?>