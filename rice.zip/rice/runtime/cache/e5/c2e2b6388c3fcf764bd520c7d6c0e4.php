<?php
//000000007200s:101:"{"session_key":"rkz20QCU1LVC1SdoZn3f2Q==","openid":"oKFP-4wyYvUqFis01gFytWLJhXr8","uid":4,"scope":16}";
?>