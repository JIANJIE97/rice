<?php
//000000007200s:104:"{"session_key":"bIZGcCLO2xMkAhs\/614STA==","openid":"oKFP-4wyYvUqFis01gFytWLJhXr8","uid":"4","scope":16}";
?>