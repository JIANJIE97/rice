<?php
//000000007200s:101:"{"session_key":"TELnd19ztdRizD7J5jCYlg==","openid":"oKFP-4wyYvUqFis01gFytWLJhXr8","uid":4,"scope":16}";
?>