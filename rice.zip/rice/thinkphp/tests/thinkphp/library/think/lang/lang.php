<?php
return [
    'load'=>'加载',
];
